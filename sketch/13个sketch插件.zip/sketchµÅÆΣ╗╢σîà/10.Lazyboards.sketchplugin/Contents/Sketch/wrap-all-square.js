var that=this;function __skpm_run(e,t){that.context=t;var r=function(e){var t={};function r(n){if(t[n])return t[n].exports;var a=t[n]={i:n,l:!1,exports:{}};return e[n].call(a.exports,a,a.exports,r),a.l=!0,a.exports}return r.m=e,r.c=t,r.d=function(e,t,n){r.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:n})},r.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},r.t=function(e,t){if(1&t&&(e=r(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var n=Object.create(null);if(r.r(n),Object.defineProperty(n,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var a in e)r.d(n,a,function(t){return e[t]}.bind(null,a));return n},r.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return r.d(t,"a",t),t},r.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},r.p="",r(r.s="./src/wrap-all-square.js")}({"./src/wrap-all-square.js":
/*!********************************!*\
  !*** ./src/wrap-all-square.js ***!
  \********************************/
/*! exports provided: default */function(e,t,r){"use strict";r.r(t);var n=r(/*! sketch */"sketch"),a=r.n(n);t.default=function(e){var t=r(/*! sketch/dom */"sketch/dom"),n=r(/*! sketch/ui */"sketch/ui"),u=t.Artboard,o=t.Rectangle,c=a.a.getSelectedDocument(),f=c.selectedPage,i=c.selectedLayers;if(0===i.length)n.message("No layers are selected.");else{var s=[],l=[];f.layers.forEach(function(e,t){l.push(e)}),i.forEach(function(e,t){"Artboard"!==e.type&&s.push(e)});var h=Math.max.apply(Math,s.map(function(e){return e.frame.width})),p=Math.max.apply(Math,s.map(function(e){return e.frame.height})),d=Math.max(h,p);s.forEach(function(e,t){var r=e.frame.x,n=e.frame.y,a=Math.abs(h-e.frame.width),c=Math.abs(p-e.frame.height);e.frame.x=a/2,e.frame.y=c/2;new u({name:e.name,parent:f,frame:new o(r-a/2,n-c/2,d,d),layers:[e]})})}}},sketch:
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */function(e,t){e.exports=require("sketch")},"sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */function(e,t){e.exports=require("sketch/dom")},"sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */function(e,t){e.exports=require("sketch/ui")}});"default"===e&&"function"==typeof r?r(t):r[e](t)}that.onRun=__skpm_run.bind(this,"default");